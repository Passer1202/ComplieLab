#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include "node.h"

#define DEBUG 0

#endif // COMMON_H